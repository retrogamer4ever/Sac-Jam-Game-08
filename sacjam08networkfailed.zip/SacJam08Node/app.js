var server  = require( "net" ).createServer();
var sockets = new Array();


//Very important when working with flash! Need to pass the policy file back to flash
//Flash will not except data if can't doesn't get policy file
function policy() 
{
  var xml = '<?xml version="1.0"?>\n<!DOCTYPE cross-domain-policy SYSTEM'
          + ' "http://www.macromedia.com/xml/dtds/cross-domain-policy.dtd">\n<cross-domain-policy>\n';

  xml += '<allow-access-from domain="*" to-ports="*"/>\n';
  xml += '</cross-domain-policy>\n';
  
  return xml;
}


function broadcast( data )
{
  //This is how we will broadcast to all socket objects
  for ( i = 0; i < sockets.length; i++ )
  {
    console.log( "writing to each socket: this data: " + data +"\n" );
    
    sockets[i].write( data + "\0");  
  }
}

function removeSocket( id )
{
  //This is how we will broadcast to all socket objects
  for ( i = 0; i < sockets.length; i++ )
  {
    if( sockets[i].id == id )
    {
      sockets.splice( i, 1 );
    }
  }
}

function event( data, socket )
{
  var eventArray = data.split( "_" );
  
  if( eventArray.length <= 1 )
  {
      console.log( "event failed " + data );
      return;
  }
  
  eventName = eventArray[0];
  eventData = eventArray[1];
  
  console.log( "eventName " + eventName );
  
  switch( eventName )
  {
    case "name":
      
      console.log( "name event triggered" );
      
      socket.name = eventData;
      
      //now we need to check if how many connected!
      if( server.connections >= 2 )
      {
        //This will tell all connected sockets to switch screens to game screen!
        broadcast( "startGame_yes" );
      }
      
      break;
      case "upyes":
      case "upno":
      case "downyes":
      case "downno":
      case "leftyes":
      case "rightyes":
      case "rightno":
      case "leftno":
        
        console.log( "moving character" + eventName );
       broadcast( data );
       break;
  }
}

server.on( "connection", function( socket )
{
  //For this particular game only ever want to connections at a time!
  if( server.connections > 2) 
  {
    console.log( "Already have two connections in play!");
    return;
  }
  
  console.log( "socket server connected" );
  
  socket.id = Math.round( new Date().getTime()  + ( Math.random() * 100 ) );
  
  socket.setEncoding( "utf8" );
  
  socket.on( "connect", function()
  {
    console.log( "socket has been connected" + socket.id );
    
    sockets.push( socket );
  });
  
  socket.on( "close", function( error )
  {
    removeSocket( socket.id );
    
    console.log( "socket has been closed" );
  });
  
  socket.on( "error", function()
  {
    console.log( "socket error has triggered" );
  });
  
  socket.on( "data", function( data )
  {
    //This is really important! Once flash connects first thing it does is 
    //ALWAYS send the policy file request so we look for that and respond by
    //writing back to flash the policy file. if this isn't done nothing will
    //work and data will not be allowed to be sent.
    if(data == '<policy-file-request/>\0')
      socket.write(policy()+"\0");
      
    //console.log( data );  
    
    event( data, socket );
    
  });
});

server.listen( 9999 );